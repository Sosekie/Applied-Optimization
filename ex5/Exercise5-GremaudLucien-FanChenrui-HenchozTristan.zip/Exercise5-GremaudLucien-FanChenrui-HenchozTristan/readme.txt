Exercise 5 - Line Search Methods

-----------------------

Exact line search for the convex quadratic function (2 pts) - Tristan Henchoz

-----------------------

Gradient descent with exact line search (2 pts) - Tristan Henchoz

-----------------------

Programming Exercise: Modified Mass Spring System (6 pts) - Chenrui Fan

I passed only two tests on GradientDescent-test and I feel that I didn't understand the content of this programming assignment. I visualised the eight images required in the question and you can see that the optimisation algorithm didn't work.
In the function add_constrained_spring_elements I used msp_.get()->add_spring_element for this function and I don't know if this is causing the error.

-----------------------

